THEME DOCS:

http://www.wpexplorer.com/powered-free-wordpress-theme/


===

LEGAL:

WPExplorer.com shall not be held liable for any damages, including, but not limited to, the loss of data or profit, arising from the use of, or inability to use, this product.